Alphabetizer: Made by Kevin Lai.

How to use:
Simply launch the program. For each book title, enter the name into the input field and press 'enter'. If the book title follows a dash ( - ), the title will be removed from the list. When you are done, press the Save button. 

The list:
The alphabetized list can be found in 'books.txt', which can also be edited to your leisure. The text file is in the same folder the .jar file is found in, and will be generated automatically if it is not found.

